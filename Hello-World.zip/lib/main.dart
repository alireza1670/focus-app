import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vibration/vibration.dart';
import 'package:audioplayers/audioplayers.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}

enum Mode { focus, breakTime, longBreak, social }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {

  Mode currentMode = Mode.focus;

  final int focusDuration = 25 * 60;
  final int breakDuration = 5 * 60;
  final int longBreakDuration = 15 * 60;
  final int socialDuration = 6 * 60;

  int remaining = 25 * 60;
  bool running = false;
  bool started = false;

  int focusCounter = 0;
  int socialLeft = 10;

  int dailyCount = 0;
  int weeklyCount = 0;
  int monthlyCount = 0;

  final int dailyGoal = 17;
  final int weeklyGoal = 100;
  final int monthlyGoal = 380;

  Timer? timer;
  late AnimationController glowController;

  final AudioPlayer player = AudioPlayer();

  @override
  void initState() {
    super.initState();
    loadStats();
    glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
      lowerBound: 0.4,
      upperBound: 1.0,
    );
  }

  @override
  void dispose() {
    glowController.dispose();
    timer?.cancel();
    player.dispose();
    super.dispose();
  }

  Future<void> loadStats() async {
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now();

    final todayKey = "${now.year}-${now.month}-${now.day}";
    final monthKey = "${now.year}-${now.month}";
    final savedDay = prefs.getString("day");
    final savedMonth = prefs.getString("month");
    final savedWeekStart = prefs.getString("weekStart");

    if (savedDay != todayKey) {
      dailyCount = 0;
      socialLeft = 10;
      await prefs.setString("day", todayKey);
      await prefs.setInt("daily", 0);
      await prefs.setInt("socialLeft", 10);
    } else {
      dailyCount = prefs.getInt("daily") ?? 0;
      socialLeft = prefs.getInt("socialLeft") ?? 10;
    }

    if (savedWeekStart == null) {
      await prefs.setString("weekStart", now.toIso8601String());
      weeklyCount = 0;
    } else {
      final start = DateTime.parse(savedWeekStart);
      if (now.difference(start).inDays >= 7) {
        weeklyCount = 0;
        await prefs.setString("weekStart", now.toIso8601String());
        await prefs.setInt("weekly", 0);
      } else {
        weeklyCount = prefs.getInt("weekly") ?? 0;
      }
    }

    if (savedMonth != monthKey) {
      monthlyCount = 0;
      await prefs.setString("month", monthKey);
      await prefs.setInt("monthly", 0);
    } else {
      monthlyCount = prefs.getInt("monthly") ?? 0;
    }

    setState(() {});
  }

  Future<void> saveStats() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt("daily", dailyCount);
    await prefs.setInt("weekly", weeklyCount);
    await prefs.setInt("monthly", monthlyCount);
    await prefs.setInt("socialLeft", socialLeft);
  }

  void startTimer() {
    if (running) return;
    if (currentMode == Mode.social && socialLeft <= 0) return;

    running = true;
    started = true;
    glowController.repeat(reverse: true);

    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (remaining > 0) {
        setState(() => remaining--);
      } else {
        timer?.cancel();
        glowController.stop();
        running = false;
        triggerAlarm();
      }
    });

    setState(() {});
  }

  Future<void> triggerAlarm() async {
    if (await Vibration.hasVibrator() ?? false) {
      Vibration.vibrate(pattern: [500, 1000], repeat: 0);
    }

    await player.setReleaseMode(ReleaseMode.loop);
    await player.play(AssetSource('alarm.mp3'));

    if (!mounted) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        title: const Text("⏰ TIME'S UP",
            style: TextStyle(color: Colors.white)),
        actions: [
          TextButton(
            onPressed: () {
              stopAlarm();
              handleNextPhase();
            },
            child: const Text("STOP 🔴"),
          )
        ],
      ),
    );
  }

  Future<void> stopAlarm() async {
    Vibration.cancel();
    await player.stop();
    Navigator.pop(context);
  }

  void handleNextPhase() {
    if (currentMode == Mode.focus) {
      focusCounter++;
      dailyCount++;
      weeklyCount++;
      monthlyCount++;

      if (dailyCount == dailyGoal) {
        showDialog(
          context: context,
          builder: (_) => const AlertDialog(
            backgroundColor: Colors.black,
            title: Text("🎯 GOAL COMPLETED",
                style: TextStyle(color: Colors.white)),
          ),
        );
      }

      if (focusCounter % 4 == 0) {
        currentMode = Mode.longBreak;
        remaining = longBreakDuration;
      } else {
        currentMode = Mode.breakTime;
        remaining = breakDuration;
      }
      startTimer();
    } else if (currentMode == Mode.social) {
      socialLeft--;
      remaining = socialDuration;
    } else {
      currentMode = Mode.focus;
      remaining = focusDuration;
    }

    started = false;
    saveStats();
    setState(() {});
  }

  void resetTimer() {
    timer?.cancel();
    glowController.stop();
    running = false;
    started = false;

    if (currentMode == Mode.focus) {
      remaining = focusDuration;
    } else if (currentMode == Mode.social) {
      remaining = socialDuration;
    }

    setState(() {});
  }

  String format(int s) {
    final m = s ~/ 60;
    final sec = s % 60;
    return "${m.toString().padLeft(2, '0')}:${sec.toString().padLeft(2, '0')}";
  }

  List<Color> gradient() {
    switch (currentMode) {
      case Mode.focus:
        return [Colors.black, const Color(0xFF3A0000)];
      case Mode.breakTime:
        return [Colors.black, const Color(0xFF003A00)];
      case Mode.longBreak:
        return [Colors.black, const Color(0xFF001F3A)];
      case Mode.social:
        return [Colors.black, const Color(0xFF3A1F00)];
    }
  }

  Color neon() {
    switch (currentMode) {
      case Mode.focus:
        return Colors.redAccent;
      case Mode.breakTime:
        return Colors.greenAccent;
      case Mode.longBreak:
        return Colors.blueAccent;
      case Mode.social:
        return Colors.orangeAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = neon();

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradient(),
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const SizedBox(width: 20),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            currentMode = Mode.focus;
                            remaining = focusDuration;
                            started = false;
                          });
                        },
                        child: Text("FOCUS",
                            style: TextStyle(
                                color: currentMode == Mode.focus
                                    ? color
                                    : Colors.grey)),
                      ),
                      const SizedBox(width: 30),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            currentMode = Mode.social;
                            remaining = socialDuration;
                            started = false;
                          });
                        },
                        child: Text("SOCIAL",
                            style: TextStyle(
                                color: currentMode == Mode.social
                                    ? color
                                    : Colors.grey)),
                      ),
                    ],
                  ),
                  IconButton(
                    icon: const Icon(Icons.bar_chart,
                        color: Colors.white),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => StatsScreen(
                            daily: dailyCount,
                            weekly: weeklyCount,
                            monthly: monthlyCount,
                            dailyGoal: dailyGoal,
                            weeklyGoal: weeklyGoal,
                            monthlyGoal: monthlyGoal,
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
              const Spacer(),
              if (started)
                AnimatedBuilder(
                  animation: glowController,
                  builder: (_, __) {
                    return Container(
                      width: 240,
                      height: 240,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color:
                                color.withOpacity(glowController.value),
                            blurRadius: 40,
                            spreadRadius: 8,
                          )
                        ],
                      ),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          SizedBox(
                            width: 220,
                            height: 220,
                            child: CircularProgressIndicator(
                              value: remaining /
                                  (currentMode == Mode.focus
                                      ? focusDuration
                                      : currentMode ==
                                              Mode.social
                                          ? socialDuration
                                          : breakDuration),
                              strokeWidth: 12,
                              color: color,
                              backgroundColor:
                                  Colors.white12,
                            ),
                          ),
                          Text(format(remaining),
                              style: const TextStyle(
                                  fontSize: 42,
                                  color: Colors.white,
                                  fontWeight:
                                      FontWeight.bold)),
                        ],
                      ),
                    );
                  },
                )
              else
                Text(format(remaining),
                    style: const TextStyle(
                        fontSize: 60,
                        color: Colors.white,
                        fontWeight:
                            FontWeight.bold)),
              const Spacer(),
              ElevatedButton(
                  onPressed: startTimer,
                  child: const Text("START")),
              const SizedBox(height: 10),
              ElevatedButton(
                  onPressed: resetTimer,
                  child: const Text("RESET")),
              if (currentMode == Mode.social)
                Padding(
                  padding: const EdgeInsets.only(top: 15),
                  child: Text("Social Left: $socialLeft",
                      style:
                          const TextStyle(color: Colors.white)),
                ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class StatsScreen extends StatelessWidget {
  final int daily;
  final int weekly;
  final int monthly;
  final int dailyGoal;
  final int weeklyGoal;
  final int monthlyGoal;

  const StatsScreen({
    super.key,
    required this.daily,
    required this.weekly,
    required this.monthly,
    required this.dailyGoal,
    required this.weeklyGoal,
    required this.monthlyGoal,
  });

  Widget circle(String title, int value, int goal, Color color) {
    double p = (value / goal).clamp(0, 1);

    return Column(
      children: [
        Text(title,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold)),
        const SizedBox(height: 15),
        Container(
          width: 190,
          height: 190,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.7),
                blurRadius: 40,
                spreadRadius: 6,
              )
            ],
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              SizedBox(
                width: 170,
                height: 170,
                child: CircularProgressIndicator(
                  value: p,
                  strokeWidth: 14,
                  color: color,
                  backgroundColor: Colors.white10,
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("${(p * 100).toInt()}%",
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Text("$value / $goal",
                      style: const TextStyle(
                          color: Colors.white70)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 50),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text("Statistics"),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              circle("TODAY", daily, dailyGoal, Colors.redAccent),
              circle("WEEKLY", weekly, weeklyGoal, Colors.blueAccent),
              circle("MONTHLY", monthly, monthlyGoal, Colors.purpleAccent),
            ],
          ),
        ),
      ),
    );
  }
}